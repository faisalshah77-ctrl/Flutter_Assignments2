package com.example.flutter_errorhndlng_viaapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
