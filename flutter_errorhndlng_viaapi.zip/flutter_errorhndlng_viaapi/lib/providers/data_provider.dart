import 'package:flutter/foundation.dart';
import '../services/api_service.dart';

enum DataStatus { loading, success, error, initial }

class DataProvider with ChangeNotifier {
  DataStatus _status = DataStatus.initial;
  List<dynamic> _data = [];
  String? _errorMessage;

  DataStatus get status => _status;
  List<dynamic> get data => _data;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _status == DataStatus.loading;
  bool get hasError => _status == DataStatus.error;

  final ApiService _apiService = ApiService(baseUrl: 'https://api.example.com');

  Future<void> fetchData() async {
    _status = DataStatus.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _apiService.get('data');
      _data = List.from(response);
      _status = DataStatus.success;
    } on ApiException catch (e) {
      _errorMessage = e.toString();
      _status = DataStatus.error;
    } catch (e) {
      _errorMessage = 'An unexpected error occurred';
      _status = DataStatus.error;
    }

    notifyListeners();
  }

  void retry() {
    fetchData();
  }

  void clearError() {
    if (_status == DataStatus.error) {
      _status = DataStatus.initial;
      _errorMessage = null;
      notifyListeners();
    }
  }
}