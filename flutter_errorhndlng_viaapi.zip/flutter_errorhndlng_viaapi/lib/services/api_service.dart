import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;

  ApiService({required this.baseUrl});

  Future<dynamic> get(String endpoint) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/$endpoint'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      return _handleResponse(response);
    } on http.ClientException catch (e) {
      throw ApiException(message: 'Network error: ${e.message}');
    } on Exception catch (e) {
      throw ApiException(message: 'Unexpected error: $e');
    }
  }

  Future<dynamic> post(String endpoint, Map<String, dynamic> data) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(data),
      ).timeout(const Duration(seconds: 10));

      return _handleResponse(response);
    } on http.ClientException catch (e) {
      throw ApiException(message: 'Network error: ${e.message}');
    } on Exception catch (e) {
      throw ApiException(message: 'Unexpected error: $e');
    }
  }

  dynamic _handleResponse(http.Response response) {
    switch (response.statusCode) {
      case 200:
        return json.decode(response.body);
      case 201:
        return json.decode(response.body);
      case 400:
        throw BadRequestException(message: 'Bad request');
      case 401:
        throw UnauthorizedException(message: 'Unauthorized access');
      case 403:
        throw ForbiddenException(message: 'Access forbidden');
      case 404:
        throw NotFoundException(message: 'Resource not found');
      case 500:
        throw InternalServerErrorException(message: 'Internal server error');
      default:
        throw ApiException(
          message: 'Error occurred with status code: ${response.statusCode}',
        );
    }
  }
}

// Custom Exception Classes
class ApiException implements Exception {
  final String message;
  ApiException({required this.message});

  @override
  String toString() => message;
}

class BadRequestException extends ApiException {
  BadRequestException({required String message}) : super(message: message);
}

class UnauthorizedException extends ApiException {
  UnauthorizedException({required String message}) : super(message: message);
}

class ForbiddenException extends ApiException {
  ForbiddenException({required String message}) : super(message: message);
}

class NotFoundException extends ApiException {
  NotFoundException({required String message}) : super(message: message);
}

class InternalServerErrorException extends ApiException {
  InternalServerErrorException({required String message}) : super(message: message);
}