import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/data_provider.dart';
import '../widgets/loading_indicator.dart';
import '../widgets/error_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Fetch data when screen initializes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = Provider.of<DataProvider>(context, listen: false);
      if (provider.status == DataStatus.initial) {
        provider.fetchData();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Viewer'),
        actions: [
          Consumer<DataProvider>(
            builder: (context, provider, _) {
              if (provider.isLoading) {
                return const Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  ),
                );
              }
              return IconButton(
                icon: const Icon(Icons.refresh),
                onPressed: provider.fetchData,
              );
            },
          ),
        ],
      ),
      body: Consumer<DataProvider>(
        builder: (context, provider, _) {
          return _buildBody(provider);
        },
      ),
    );
  }

  Widget _buildBody(DataProvider provider) {
    switch (provider.status) {
      case DataStatus.initial:
      case DataStatus.loading:
        return const LoadingIndicator(
          message: 'Fetching data...',
        );
      case DataStatus.error:
        return CustomErrorWidget(
          message: provider.errorMessage ?? 'An error occurred',
          onRetry: provider.retry,
        );
      case DataStatus.success:
        return _buildDataList(provider.data);
    }
  }

  Widget _buildDataList(List<dynamic> data) {
    if (data.isEmpty) {
      return const Center(
        child: Text('No data available'),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        final provider = Provider.of<DataProvider>(context, listen: false);
        await provider.fetchData();
      },
      child: ListView.builder(
        itemCount: data.length,
        itemBuilder: (context, index) {
          final item = data[index];
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              title: Text(item['title'] ?? 'No Title'),
              subtitle: Text(item['description'] ?? 'No Description'),
              trailing: const Icon(Icons.arrow_forward_ios),
            ),
          );
        },
      ),
    );
  }
}