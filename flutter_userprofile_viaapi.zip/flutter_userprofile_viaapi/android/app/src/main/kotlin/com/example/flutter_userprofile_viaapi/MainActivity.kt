package com.example.flutter_userprofile_viaapi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
