import 'package:flutter/foundation.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

enum UserState { loading, loaded, error }

class UserProvider extends ChangeNotifier {
  User? _currentUser;
  List<User> _users = [];
  UserState _state = UserState.loading;
  String _errorMessage = '';
  final ApiService _apiService = ApiService();

  User? get currentUser => _currentUser;
  List<User> get users => _users;
  UserState get state => _state;
  String get errorMessage => _errorMessage;

  Future<void> fetchUser() async {
    _state = UserState.loading;
    _errorMessage = '';
    notifyListeners();

    try {
      _currentUser = await _apiService.fetchUser();
      _state = UserState.loaded;
    } catch (e) {
      _state = UserState.error;
      _errorMessage = e.toString();
    }
    notifyListeners();
  }

  Future<void> fetchMultipleUsers(int count) async {
    _state = UserState.loading;
    notifyListeners();

    try {
      _users = await _apiService.fetchMultipleUsers(count);
      _state = UserState.loaded;
    } catch (e) {
      _state = UserState.error;
      _errorMessage = e.toString();
    }
    notifyListeners();
  }

  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }
}