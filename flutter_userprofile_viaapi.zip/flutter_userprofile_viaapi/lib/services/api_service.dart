import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/user_model.dart';

class ApiService {
  static const String baseUrl = 'https://dummyjson.com/users/1';
  static const String apiSeed = 'flutter_app';

  Future<User> fetchUser() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl?seed=$apiSeed'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final userJson = jsonData['results'][0];
        return User.fromJson(userJson);
      } else {
        throw Exception('Failed to load user data: ${response.statusCode}');
      }
    } on SocketException {
      throw Exception('No internet connection');
    } on http.ClientException {
      throw Exception('Network error occurred');
    } catch (e) {
      throw Exception('Failed to fetch user: $e');
    }
  }

  Future<List<User>> fetchMultipleUsers(int count) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl?results=$count&seed=$apiSeed'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final List<dynamic> usersJson = jsonData['results'];
        return usersJson.map((json) => User.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load users: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to fetch users: $e');
    }
  }
}