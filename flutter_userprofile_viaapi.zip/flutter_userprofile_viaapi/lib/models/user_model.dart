class User {
  final String id;
  final String name;
  final String email;
  final String profilePicture;
  final String phone;
  final String location;
  final DateTime dateOfBirth;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.profilePicture,
    required this.phone,
    required this.location,
    required this.dateOfBirth,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id']['value'] ?? 'N/A',
      name: '${json['name']['first']} ${json['name']['last']}',
      email: json['email'],
      profilePicture: json['picture']['large'],
      phone: json['phone'],
      location: '${json['location']['city']}, ${json['location']['country']}',
      dateOfBirth: DateTime.parse(json['dob']['date']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'profilePicture': profilePicture,
      'phone': phone,
      'location': location,
      'dateOfBirth': dateOfBirth.toIso8601String(),
    };
  }
}