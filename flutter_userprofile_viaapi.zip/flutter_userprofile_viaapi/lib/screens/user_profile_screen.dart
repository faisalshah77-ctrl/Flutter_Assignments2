import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../user_providers/user_provider.dart';
import '../widgets/user_profile_card.dart';
import '../widgets/loading_widget.dart';
//import '../widgets/error_widget.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<UserProvider>().fetchUser();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Profile'),
        centerTitle: true,
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<UserProvider>().fetchUser();
            },
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.deepPurple,
              Colors.purple.shade300,
            ],
          ),
        ),
        child: Consumer<UserProvider>(
          builder: (context, userProvider, child) {
            switch (userProvider.state) {
              case UserState.loading:
                return const LoadingWidget();
              case UserState.error:
              return Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          userProvider.errorMessage,
          style: const TextStyle(color: Colors.red),
        ),
        const SizedBox(height: 10),
        ElevatedButton(
          onPressed: userProvider.fetchUser,
          child: const Text('Retry'),
        ),
      ],
    ),
  );
  
        /*        return ErrorWidget(
                  message: userProvider.errorMessage,
                  onRetry: () {
                    userProvider.fetchUser();
                  },
                );
          */
              case UserState.loaded:
                if (userProvider.currentUser != null) {
                  return SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: UserProfileCard(
                      user: userProvider.currentUser!,
                      onRefresh: () {
                        userProvider.fetchUser();
                      },
                    ),
                  );
                } else {

                   return Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          userProvider.errorMessage,
          style: const TextStyle(color: Colors.red),
        ),
        const SizedBox(height: 10),
        ElevatedButton(
          onPressed: userProvider.fetchUser,
          child: const Text('No user data available'),
        ),
      ],
    ),
  );
   /*              
                 return const ErrorWidget(
                    message: 'No user data available',
                    onRetry: () {
                      // Retry logic handled by ErrorWidget
                    },
                  );
  */
                }
            }
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          context.read<UserProvider>().fetchUser();
        },
        icon: const Icon(Icons.person_add),
        label: const Text('New User'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.deepPurple,
        elevation: 4,
      ),
    );
  }
}