import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/user_model.dart';

class UserProfileCard extends StatelessWidget {
  final User user;
  final VoidCallback onRefresh;

  const UserProfileCard({
    super.key,
    required this.user,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // Header with refresh button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'User Profile',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Colors.deepPurple,
                      ),
                ),
                IconButton(
                  onPressed: onRefresh,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Refresh Profile',
                  style: IconButton.styleFrom(
                    backgroundColor: Colors.deepPurple.withOpacity(0.1),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Profile Picture
            Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.deepPurple,
                  width: 4,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.deepPurple.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(75),
                child: CachedNetworkImage(
                  imageUrl: user.profilePicture,
                  placeholder: (context, url) => Container(
                    color: Colors.grey[200],
                    child: const Center(
                      child: CircularProgressIndicator(),
                    ),
                  ),
                  errorWidget: (context, url, error) => Container(
                    color: Colors.grey[200],
                    child: const Icon(
                      Icons.person,
                      size: 60,
                      color: Colors.grey,
                    ),
                  ),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 30),

            // User Details
            _buildDetailRow(
              context,
              icon: Icons.person,
              label: 'Name',
              value: user.name,
            ),
            const Divider(height: 30),
            _buildDetailRow(
              context,
              icon: Icons.email,
              label: 'Email',
              value: user.email,
            ),
            const Divider(height: 30),
            _buildDetailRow(
              context,
              icon: Icons.phone,
              label: 'Phone',
              value: user.phone,
            ),
            const Divider(height: 30),
            _buildDetailRow(
              context,
              icon: Icons.location_on,
              label: 'Location',
              value: user.location,
            ),
            const Divider(height: 30),
            _buildDetailRow(
              context,
              icon: Icons.cake,
              label: 'Date of Birth',
              value: '${user.dateOfBirth.day}/${user.dateOfBirth.month}/${user.dateOfBirth.year}',
            ),

            const SizedBox(height: 30),
            // User ID
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                color: Colors.deepPurple.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                'User ID: ${user.id}',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.deepPurple,
                      fontFamily: 'monospace',
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color: Colors.deepPurple,
          size: 24,
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}